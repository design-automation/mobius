import sys
import os

from tornado.testing import AsyncHTTPTestCase
from tornado.escape import to_unicode, json_decode, json_encode

from server import ReloadApplication

PROJECT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")

class TestCase(AsyncHTTPTestCase):

	def setUp(self):
		super(TestCase, self).setUp()
		self.initialize()

	def initialize(self):
		pass

	def get_app(self):
		self.server = ReloadApplication(port=8881)
		return self.server

class TestBase(TestCase):

	def initialize(self):
		sitePath = os.path.join(DATA_DIR, "ExampleSite")
		self.server.mount(sitePath)

	def testIndex(self):
		response = self.fetch("/ExampleSite/index.html", method="GET")
		self.assertEqual(response.code, 200, response.body)
		self.assertEqual(response.body, "Hello!\n<script src=\"/_server/server.js\"></script>")

	def testDefaultIndex(self):
		response = self.fetch("/ExampleSite/", method="GET")
		self.assertEqual(response.code, 200, response.body)
		self.assertEqual(response.body, "Hello!\n<script src=\"/_server/server.js\"></script>")

	def testNotAppend(self):
		response = self.fetch("/ExampleSite/test.js", method="GET")
		self.assertEqual(response.code, 200, response.body)
		self.assertEqual(response.body, "console.log(\"hello\")")

	def testServerScript(self):
		response = self.fetch("/_server/server.js", method="GET")
		
		with open(os.path.join(PROJECT_DIR, "www", "server.js"), "r") as f:
			self.assertEqual(response.code, 200, response.body)
			self.assertEqual(response.body, f.read())

class TestAPI(TestCase):

	def initialize(self):
		self.sitePath = os.path.join(DATA_DIR, "ExampleSite")
		self.server.mount(self.sitePath)

	def testList(self):
		response = self.fetch("/_server/api/list", method="GET")
		self.assertEqual(response.code, 200, response.body)
		self.assertEqual(response.body, '{"result": [{"path": "%s", "handle": "ExampleSite"}]}' % self.sitePath)

class TestAPIMount(TestCase):

	def initialize(self):
		self.sitePath = os.path.join(DATA_DIR, "ExampleSite")

	def testMount(self):
		response = self.fetch("/_server/api/mount", method="POST", body='{"path": "%s"}' % self.sitePath)
		self.assertEqual(response.code, 200, response.body)
		self.assertEqual(response.body, '{"result": "OK"}')

		response = self.fetch("/_server/api/list", method="GET")
		self.assertEqual(response.code, 200, response.body)
		self.assertEqual(response.body, '{"result": [{"path": "%s", "handle": "ExampleSite"}]}' % self.sitePath)

	def testMountUnexisting(self):
		response = self.fetch("/_server/api/mount", method="POST", body='{"path": "/a/b/c"}')
		self.assertEqual(response.code, 500, response.body)
		self.assertEqual(response.body, '{"error": "Path does not exist /a/b/c"}')


class TestAPIUnmount(TestCase):

	def initialize(self):
		self.sitePath = os.path.join(DATA_DIR, "ExampleSite")
		self.server.mount(self.sitePath)

	def testUnmount(self):
		response = self.fetch("/_server/api/unmount", method="POST", body='{"path": "%s"}' % self.sitePath)
		self.assertEqual(response.code, 200, response.body)
		self.assertEqual(response.body, '{"result": "OK"}')

		response = self.fetch("/_server/api/list", method="GET")
		self.assertEqual(response.code, 200, response.body)
		self.assertEqual(response.body, '{"result": []}')

class TestAPIEval(TestCase):

	def initialize(self):
		self.sitePath = os.path.join(DATA_DIR, "ExampleSite")
		self.server.mount(self.sitePath)

	def testEval(self):
		response = self.fetch("/_server/api/eval", method="POST", body=json_encode({"script": "console.log('hello')"}))
		self.assertEqual(response.code, 200, response.body)
		self.assertEqual(response.body, '{"result": "OK"}')

