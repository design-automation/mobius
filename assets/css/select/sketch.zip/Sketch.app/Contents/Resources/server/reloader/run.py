from server import ReloadApplication

if __name__ == "__main__":

	server = ReloadApplication(port=8080)

	print server.url
	
	server.start()

