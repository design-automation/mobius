#!/usr/bin/env python
# encoding: utf-8

import sys
import os
import logging
import time
import threading
import socket
import traceback
import random
import json

# Patch to not access stuff in /etc for sandbox
import mimetypes
mimetypes.knownfiles = []

logging.basicConfig(level=logging.DEBUG, format="%(message)s")

def main():

	exit_without_process(os.environ.get("PARENT_PROCESS", None), interval=10)
	cleanup_system_path()
	
	from server import ReloadApplication

	port = 8080
	port = get_open_port("127.0.0.1", port)
	server = ReloadApplication(port=port)

	def ready_handler():
		logging.info(json.dumps({"signal": "ready", "url": server.url}))
		logging.info("Server ready at: %s", server.url)

	wait_for_startup(port, ready_handler)

	# @atexit.register
	# def goodbye():
	# 	logging.info("Stopping server... cleaning up.")
	# 	tornado.ioloop.IOLoop.instance().stop()

	try:
		server.start()
	except Exception, e:
		logging.error("\n".join(traceback.format_exception(*sys.exc_info())))


	# sys.exit()


def cleanup_system_path():

	sys_path = []

	for path in sys.path:
		if "site-packages" not in path:
			sys_path.append(path)

	sys.path = sys_path

	sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'vendor/packages.zip'))
	sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'vendor/'))
	sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'reloader/'))

def is_process_running(pid):
	try:
		os.kill(pid, 0)
		return True
	except OSError:
		return False

def exit_without_process(pid, interval=1):

	if not pid:
		return

	pid = int(pid)
	
	def check():
		while is_process_running(pid):
			time.sleep(interval)
			
		os.kill(os.getpid(), 9)
	
	thread = threading.Thread(target=check)
	thread.daemon = True
	thread.start()

def is_port_open(host, port):

	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	s.settimeout(0.5)

	try:
		s.connect((host, int(port)))
		s.shutdown(2)
		return False
	except Exception, e:
		return True

def get_open_port(host, startPort):

	attempts = 0

	while True and attempts < 10:

		print "Trying", host, startPort

		if is_port_open(host, startPort):
			return startPort
		
		startPort += 1
		attempts += 1

	raise Exception("Could not find open port from %s", startPort)

def wait_for_startup(port, handler, interval=0.1):
	
	def check():
		while is_port_open("127.0.0.1", port) is False:
			time.sleep(interval)
			
		handler()
	
	thread = threading.Thread(target=check)
	thread.daemon = True
	thread.start()

if __name__ == "__main__":
	main()
